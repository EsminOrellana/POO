/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package helpers;

/**
 *
 * @author HP
 */
public class Doctor1 {
    
    public String nombre;
    private String experiencia;
    private int edad;
    
    public  Doctor1 (String nombre, String experiencia, int edad ){
        this.nombre=nombre;
        this.edad=edad;
        this.experiencia=experiencia;
        
    }
    public void imprimirnombre(){
        System.out.print(nombre);
    }
    public void establecerEdad(int_edad){
       this.edad=_edad;
   }
   public int obtenerEdad(){
       return edad;
   }
}
