/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class RECURSOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // Declaracion de variables
        int edad=21; 
        int n1=5; // 
        int n2=10;
        int resultado=0;
        int i=1;
     
        // Mensaje de Inicio
        System.out.println("\n\n");
        System.out.print("Programación Orientada a Objetos 2021\n\n");
        
        //Mostrando la edad declarada
        System.out.println(">=21: MENSAJE DE MAYOR DE EDAD, DE LO CONTRARIO MENOR DE EDAD\n");
        System.out.println("La edad es: "+edad);
        
        //Inicializacion de parametro, si edad es menor mostrar mensaje que es menor de edad, de lo contrario sera mayor de edad
        if(edad>=21){
            System.out.print("MAYOR DE EDAD\n\n");
           
        }
        else{
            System.out.println("MENOR DE EDAD\n\n");
            
        }
        
        //Operacion aritmetica, multiplicacion de dos digitos.
        System.out.println("MULTIPLICACION DE VALORES 5 x 10");
        resultado= n1*n2;
        System.out.println("EL RESULTADO DE LA MULTIPLICACION ES: "+resultado);
        System.out.println("\n");
        // LISTA DE 
        
        System.out.println("LISTA DE NUMEROS HASTA EL VALOR DE LA EDAD: 21");
        for(i=1; i<=edad; i=i+1){
            System.out.println(i);
        }
    }
    
}
