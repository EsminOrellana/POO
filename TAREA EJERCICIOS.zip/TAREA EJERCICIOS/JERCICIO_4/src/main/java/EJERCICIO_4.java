/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class EJERCICIO_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int contador=1;
        while(contador<=20){
            System.out.println("SAN PEDRO SULA\n");
            System.out.println("VILLANUEVA\n");
            System.out.println("CHOLOMA\n");
            contador++;
        }
        
        
    }
    
}
