/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class EJERCICIO_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.print("\n\nVARIABLES: M=6, T=1, K=-10 \n\n");
        int M=6, T=1, K=-10;
        System.out.print("M>T?=\n");
        if(M>T){
            System.out.println("VERDADERO\n\n");
        }
        else{
            System.out.print("FALSO\n\n");
        }
        System.out.print("T / K == -5?\n");
        if(T/K==-5){
            System.out.print("VERDADERO\n\n");
        }
        else{
            System.out.print("FALSO\n\n");
        }
        System.out.print("(M+T == 7) || (M-T == 5)\n");
        if(M+T == 7 || M-T == 5){
            System.out.println("VERDADERO\n\n");
        }
        else{
            System.out.println("FALSO\n\n");
        }
        
    }
    
}
