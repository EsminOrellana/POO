/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class esmin {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int numero1=100;
        int numero2=2;
        int suma=0, resta=0,multiplicacion=0, division=0;
        resta=numero1-numero2;
        suma=numero1 + numero2;
        multiplicacion=numero1 *numero2;
        division=numero1 / numero2;
        System.out.println("TOTAL DE LA SUMA ES: "+suma);
        System.out.println("TOTAL DE LA RESTA ES: "+resta);
        System.out.println("TOTAL DE LA MULTIPLICACION ES: "+multiplicacion); 
        System.out.println("TOTAL DE LA DIVISION ES: "+division);
    }
    
}
