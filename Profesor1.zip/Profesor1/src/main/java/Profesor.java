/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Profesor {
    
    // DECLARANDO VARIABLES
String nombre;
String apellido;
String edad;
String profesion;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        // CREANDO EL OBJETO
        Profesor profesor= new Profesor();
        profesor.nombre=("ESMIN");
        profesor.apellido=("ORELLANA");
        profesor.edad=("22");
        profesor.profesion=("DOCENTE");
        
        // MOSTRANDO EN CONSOLA EL OBJETO
        System.out.print("DESCRIPCION DE UNA PERSONA\n");
        System.out.print("NOMBRE DEL PROFESOR:"+profesor.nombre);
        System.out.println("\n");
        System.out.print("APELLIDO DEL PROFESOR:"+profesor.apellido);
        System.out.println("\n");
        System.out.print("EDAD DEL PROFESOR:"+profesor.edad);
        System.out.println("\n");
        System.out.print("PROFESION DEL PROFESOR:"+profesor.profesion);
        System.out.println("\n");
    }
    
}
