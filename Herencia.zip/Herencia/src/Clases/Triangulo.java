/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

public class Triangulo extends Clase_padre_Formas{
    
    public Triangulo(){
        super.EstablecerDibujo = "TRIANGULO";
        super.Calculararea = "14";
}
}
